CONFIG = {
    "bucket_name": "tp_dicom",
    "output_image_prefix": "OUTPUT_IMAGE_FOLDER/",  # Folder inside the bucket
    "output_metadata_prefix": "OUTPUT_JSON_FOLDER/",  # Folder inside the bucket
    "bq_dataset": "TP_api_integration",
    "bq_table": "dicom_metadata1"
}